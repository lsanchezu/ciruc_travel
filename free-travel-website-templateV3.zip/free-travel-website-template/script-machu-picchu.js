// const contenidoEn = fetch('contenido_en.json')
//   .then(response => response.json())
//   .then(data => {
//     return data;
//   });

// const contenidoEs = fetch('contenido_es.json')
//   .then(response => response.json())
//   .then(data => {
//     return data;
//   });

// let idioma = 'es'; // variable para seleccionar el idioma

// // Cargar contenido en español al comienzo
// contenidoEs.then(contenido => {
//   document.getElementById('titulo').innerHTML = contenido.titulo;
//   document.getElementById('descripcion').innerHTML = contenido.descripcion;
//   document.getElementById('seccion1-titulo').innerHTML = contenido.seccion1.titulo;
//   document.getElementById('seccion1-texto').innerHTML = contenido.seccion1.texto;
//   document.getElementById('seccion2-titulo').innerHTML = contenido.seccion2.titulo;
//   document.getElementById('seccion2-texto').innerHTML = contenido.seccion2.texto;
// });

// // Agregar evento de cambio de idioma
// document.getElementById('boton-cambiar-idioma').addEventListener('click', () => {
//   if (idioma === 'es') {
//     idioma = 'en';
//     contenidoEn.then(contenido => {
//       document.getElementById('titulo').innerHTML = contenido.titulo;
//       document.getElementById('descripcion').innerHTML = contenido.descripcion;
//       document.getElementById('seccion1-titulo').innerHTML = contenido.seccion1.titulo;
//       document.getElementById('seccion1-texto').innerHTML = contenido.seccion1.texto;
//       document.getElementById('seccion2-titulo').innerHTML = contenido.seccion2.titulo;
//       document.getElementById('seccion2-texto').innerHTML = contenido.seccion2.texto;
//     });
//   } else {
//     idioma = 'es';
//     contenidoEs.then(contenido => {
//       document.getElementById('titulo').innerHTML = contenido.titulo;
//       document.getElementById('descripcion').innerHTML = contenido.descripcion;
//       document.getElementById('seccion1-titulo').innerHTML = contenido.seccion1.titulo;
//       document.getElementById('seccion1-texto').innerHTML = contenido.seccion1.texto;
//       document.getElementById('seccion2-titulo').innerHTML = contenido.seccion2.titulo;
//       document.getElementById('seccion2-texto').innerHTML = contenido.seccion2.texto;
//     });
//   }
// });
const selector = document.getElementById('selector');
const boton = document.getElementById('boton');

if (selector && boton) {
  selector.addEventListener('change', () => {
    const seleccionado = selector.value;
    if (seleccionado !== "") {
      const seccion = document.querySelector(seleccionado);
      seccion.scrollIntoView({ behavior: 'smooth' });
    }
  });

  boton.addEventListener('click', () => {
    const seleccionado = selector.value;
    if (seleccionado !== "") {
      const seccion = document.querySelector(seleccionado);
      seccion.scrollIntoView({ behavior: 'smooth' });
    }
  });
} else {
  console.error("No se encontraron los elementos selector o boton");
}